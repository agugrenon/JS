let nombre = prompt("¿Cómo te llamás?");
let saldo = 5000;

alert("Hola " + nombre + ", tenés $" + saldo);

let producto = "Campera";
let precio = 3000;

let comprar = confirm("¿Querés comprar una " + producto + " por $" + precio + "?");

if (comprar) {
  if (saldo >= precio) {
    saldo -= precio;
    alert("¡Compra realizada! Te quedan $" + saldo);
    console.log("Compra exitosa de " + producto);
  } else {
    alert("No tenés suficiente saldo.");
    console.log("Saldo insuficiente.");
  }
} else {
  alert("No realizaste ninguna compra.");
  console.log("El usuario canceló la compra.");
}
